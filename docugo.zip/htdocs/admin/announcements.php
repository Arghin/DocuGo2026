<?php
require_once '../includes/config.php';
require_once '../includes/announcement_helper.php';
require_once '../includes/mailer.php';
requireAdmin();

$conn = getConnection();

// Ensure announcements table exists
$conn->query("
    CREATE TABLE IF NOT EXISTS announcements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        target_type ENUM('all', 'user') DEFAULT 'all',
        target_user_id INT DEFAULT NULL,
        created_by INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (target_user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

// Get counts for sidebar badges
$pendingReqs = $conn->query("SELECT COUNT(*) as c FROM document_requests WHERE status = 'pending'")->fetch_assoc()['c'];
$pendingAccs = $conn->query("SELECT COUNT(*) as c FROM users WHERE status = 'pending'")->fetch_assoc()['c'];

// ── AJAX handlers (must be before any HTML output) ──────────────
if (isset($_GET['ajax_search_users'])) {
    $users = searchUsers($conn, $_GET['q'] ?? '');
    header('Content-Type: application/json');
    echo json_encode($users);
    exit();
}
if (isset($_GET['ajax_get_announcement'])) {
    $ann = getAnnouncementById($conn, intval($_GET['id']));
    header('Content-Type: application/json');
    echo json_encode($ann ?: []);
    exit();
}
if (isset($_GET['ajax_get_user'])) {
    $id = intval($_GET['id']);
    $user = $conn->query("SELECT id, first_name, last_name, email, role FROM users WHERE id = $id")->fetch_assoc();
    header('Content-Type: application/json');
    echo json_encode($user ?: []);
    exit();
}

// ── Handle CRUD operations ───────────────────────────────────
$message = '';
$messageType = '';
$emailCount = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create' || $action === 'update') {
        $title = trim($_POST['title'] ?? '');
        $messageText = trim($_POST['message'] ?? '');
        $targetType = $_POST['target_type'] ?? 'all';
        $targetUserId = !empty($_POST['target_user_id']) ? intval($_POST['target_user_id']) : null;
        $sendEmailAlumni = isset($_POST['send_email_alumni']) ? 1 : 0;

        if (empty($title) || empty($messageText)) {
            $message = 'Title and message are required.';
            $messageType = 'error';
        } else {
            if ($action === 'create') {
                $result = createAnnouncement($conn, $title, $messageText, $targetType, $targetUserId, $_SESSION['user_id']);
                if ($result['success']) {
                    $message = 'Announcement created successfully.';
                    $messageType = 'success';
                    $announcementId = $result['id'];
                    
                    // Send emails to alumni if checkbox is checked
                    if ($sendEmailAlumni && $announcementId) {
                        $emailCount = sendAnnouncementToAlumni($conn, $title, $messageText);
                        if ($emailCount > 0) {
                            $message .= " Email sent to {$emailCount} active alumni.";
                            if ($emailCount >= 50) {
                                $message .= " (Limited to first 50 active alumni)";
                            }
                        } elseif ($emailCount === 0) {
                            $message .= " No active alumni found to email.";
                        }
                    }
                } else {
                    $message = 'Failed to create announcement.';
                    $messageType = 'error';
                }
            } else {
                $id = intval($_POST['announcement_id'] ?? 0);
                $result = updateAnnouncement($conn, $id, $title, $messageText, $targetType, $targetUserId);
                if ($result) {
                    $message = 'Announcement updated successfully.';
                    $messageType = 'success';
                    
                    // Send emails to alumni if checkbox is checked
                    if ($sendEmailAlumni && $id) {
                        $emailCount = sendAnnouncementToAlumni($conn, $title, $messageText);
                        if ($emailCount > 0) {
                            $message .= " Email sent to {$emailCount} active alumni.";
                            if ($emailCount >= 50) {
                                $message .= " (Limited to first 50 active alumni)";
                            }
                        } elseif ($emailCount === 0) {
                            $message .= " No active alumni found to email.";
                        }
                    }
                } else {
                    $message = 'Failed to update announcement.';
                    $messageType = 'error';
                }
            }
        }
    } elseif ($action === 'delete') {
        $id = intval($_POST['announcement_id'] ?? 0);
        if (deleteAnnouncement($conn, $id)) {
            $message = 'Announcement deleted successfully.';
            $messageType = 'success';
        } else {
            $message = 'Failed to delete announcement.';
            $messageType = 'error';
        }
    }

    header("Location: announcements.php?msg=" . urlencode($message) . "&msgtype=" . $messageType);
    exit();
}

// Function to send announcement emails to active alumni
function sendAnnouncementToAlumni($conn, $title, $messageText) {
    // Query active alumni (role='alumni', status='active'), limit 50
    $query = "
        SELECT id, first_name, last_name, email 
        FROM users 
        WHERE role = 'alumni' AND status = 'active'
        ORDER BY id
        LIMIT 50
    ";
    $result = $conn->query($query);
    
    if (!$result || $result->num_rows === 0) {
        return 0;
    }
    
    $sentCount = 0;
    $subject = "DocuGo Announcement: " . $title;
    
    // Build email body template matching mailer.php style
    while ($alumni = $result->fetch_assoc()) {
        $firstName = htmlspecialchars($alumni['first_name']);
        $announcementTitle = htmlspecialchars($title);
        $announcementMessage = nl2br(htmlspecialchars($messageText));
        
        $emailBody = '
        <div style="font-family:Arial;background:#f0f4f8;padding:20px;">
            <div style="max-width:520px;margin:auto;background:#fff;border-radius:10px;overflow:hidden;">
                
                <div style="background:#1a56db;padding:20px;color:white;">
                    <h2 style="margin:0;">DocuGo</h2>
                </div>

                <div style="padding:20px;">
                    <h3>Hello ' . $firstName . ' 👋</h3>
                    
                    <div style="background:#f0f7ff;padding:15px;border-radius:8px;margin:15px 0;border-left:4px solid #1a56db;">
                        <h4 style="margin:0 0 10px 0;color:#1a56db;">📢 ' . $announcementTitle . '</h4>
                        <p style="margin:0;color:#333;line-height:1.5;">' . $announcementMessage . '</p>
                    </div>
                    
                    <p style="color:#666;font-size:12px;">This announcement was sent by the ADFC DocuGo administration.</p>
                </div>
                
                <div style="background:#f8f9fa;padding:12px;text-align:center;font-size:11px;color:#999;">
                    &copy; ' . date('Y') . ' Asian Development Foundation College
                </div>
            </div>
        </div>';
        
        if (sendWithPHPMailer($alumni['email'], $firstName, $subject, $emailBody)) {
            $sentCount++;
        }
    }
    
    return $sentCount;
}

// Get flash message
if (isset($_GET['msg'])) {
    $message = $_GET['msg'];
    $messageType = $_GET['msgtype'] ?? 'success';
}

// Fetch all announcements
$announcements = $conn->query("
    SELECT a.*, u.first_name, u.last_name, u.email as creator_email
    FROM announcements a
    LEFT JOIN users u ON a.created_by = u.id
    ORDER BY a.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

// Get stats
$totalAnnouncements = count($announcements);
$targetedAnnouncements = count(array_filter($announcements, fn($a) => $a['target_type'] === 'user'));
$systemWideAnnouncements = count(array_filter($announcements, fn($a) => $a['target_type'] === 'all'));

// Get active alumni count for UI note
$activeAlumniCount = $conn->query("SELECT COUNT(*) as c FROM users WHERE role = 'alumni' AND status = 'active'")->fetch_assoc()['c'];

$conn->close();

function escape($v) { return htmlspecialchars($v ?? ''); }

function timeAgo($datetime) {
    if (!$datetime) return '—';
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff/60) . ' minutes ago';
    if ($diff < 86400) return floor($diff/3600) . ' hours ago';
    if ($diff < 604800) return floor($diff/86400) . ' days ago';
    return date('M d, Y', strtotime($datetime));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Announcements — ADFC DocuGo</title>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* ========== THEME VARIABLES ========== */
        :root {
            --primary:    #1a3ec7;
            --primary-dk: #1230a0;
            --accent:     #3b6bff;
            --accent2:    #6b9fff;
            --bg:         #080e28;
            --bg2:        #0b1535;
            --bg3:        #0e1c42;
            --surface:    rgba(255,255,255,0.05);
            --surface-hv: rgba(255,255,255,0.08);
            --border:     rgba(255,255,255,0.08);
            --border-hv:  rgba(59,107,255,0.25);
            --text:       #dce6f8;
            --text-muted: #7a96c4;
            --text-dim:   #4a6190;
            --green:      #4cd98a;
            --yellow:     #fbbf24;
            --purple:     #a78bfa;
            --red:        #f87171;
            --blue:       #60a5fa;
            --radius-sm:  8px;
            --radius-md:  12px;
            --radius-lg:  16px;
            --radius-xl:  24px;
            --sidebar-width: 260px;
            --ease-out:   cubic-bezier(0.16, 1, 0.3, 1);
            --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
            
            --sidebar-bg: #0f2a6b;
            --sidebar-border: rgba(255,255,255,0.1);
            --sidebar-text: #b8c9f0;
            --sidebar-text-hover: #ffffff;
            --sidebar-active-bg: rgba(59,107,255,0.25);
            --sidebar-active-color: #ffffff;
            --sidebar-section: #8eabff;
            --card-bg: rgba(255,255,255,0.05);
        }

        body.light {
            --bg:         #eef2ff;
            --bg2:        #e2e9ff;
            --bg3:        #d8e2ff;
            --surface:    rgba(255,255,255,0.6);
            --surface-hv: rgba(255,255,255,0.85);
            --border:     rgba(26,62,199,0.1);
            --border-hv:  rgba(26,62,199,0.25);
            --text:       #0c1836;
            --text-muted: #3d5a92;
            --text-dim:   #7a96c4;
            --card-bg: #ffffff;
            
            --sidebar-bg: #2d4ed6;
            --sidebar-border: rgba(255,255,255,0.15);
            --sidebar-text: #e0e8ff;
            --sidebar-text-hover: #ffffff;
            --sidebar-active-bg: rgba(255,255,255,0.2);
            --sidebar-active-color: #ffffff;
            --sidebar-section: #c7d5ff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            transition: background 0.3s, color 0.3s;
            overflow-x: hidden;
            display: flex;
        }

        /* ========== SIDEBAR ========== */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--sidebar-border);
            display: flex;
            flex-direction: column;
            z-index: 100;
            transition: transform 0.3s var(--ease-out), background 0.3s;
        }

        .sidebar-brand {
            padding: 1.5rem 1.2rem;
            border-bottom: 1px solid var(--sidebar-border);
            margin-bottom: 1rem;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-logo img {
            width: 48px;
            height: 48px;
            object-fit: contain;
            border-radius: 12px;
            transition: transform 0.3s var(--ease-spring);
        }

        .brand-logo img:hover {
            transform: rotate(-5deg) scale(1.05);
        }

        .brand-text {
            flex: 1;
        }

        .brand-name {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 0.9rem;
            color: white;
            line-height: 1.2;
        }

        .brand-sub {
            font-size: 0.55rem;
            color: rgba(255,255,255,0.7);
            margin-top: 3px;
            letter-spacing: 0.3px;
        }

        .sidebar-menu {
            flex: 1;
            padding: 0 0.8rem;
        }

        .menu-section {
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--sidebar-section);
            padding: 0.8rem 0.8rem 0.5rem;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 0.8rem;
            border-radius: var(--radius-sm);
            color: var(--sidebar-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }

        .menu-item:hover {
            background: var(--sidebar-active-bg);
            color: var(--sidebar-text-hover);
        }

        .menu-item.active {
            background: var(--sidebar-active-bg);
            color: var(--sidebar-active-color);
            border-left: 2px solid white;
        }

        .menu-icon {
            font-size: 1.1rem;
            width: 24px;
        }

        .menu-badge {
            margin-left: auto;
            background: rgba(255,255,255,0.25);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 20px;
        }

        .menu-badge.yellow { background: var(--yellow); color: #1a1a2e; }

        .sidebar-footer {
            padding: 1rem 0.8rem;
            border-top: 1px solid var(--sidebar-border);
            margin-top: auto;
        }

        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.7rem 0.8rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: var(--radius-sm);
            transition: all 0.2s;
        }

        .sidebar-footer a:hover {
            background: var(--sidebar-active-bg);
            color: var(--red);
        }

        /* ========== MAIN CONTENT ========== */
        .main {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem;
            min-height: 100vh;
            flex: 1;
        }

        /* Topbar */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .topbar-left h1 {
            font-family: 'Sora', sans-serif;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 0.2rem;
        }

        .topbar-left p {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .admin-info, .topbar-date {
            background: var(--surface);
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            font-size: 0.85rem;
            border: 1px solid var(--border);
        }

        /* Alert */
        .alert {
            padding: 0.85rem 1rem;
            border-radius: 10px;
            margin-bottom: 1.2rem;
            font-size: 0.85rem;
        }
        .alert-success { background: rgba(76,217,138,0.15); color: var(--green); border-left: 4px solid var(--green); }
        .alert-error   { background: rgba(248,113,113,0.15); color: var(--red); border-left: 4px solid var(--red); }

        /* Stats Row */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 1rem 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-2px); border-color: var(--border-hv); }
        .stat-icon {
            width: 48px; height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .stat-icon.blue { background: rgba(96,165,250,0.15); color: #60a5fa; }
        .stat-icon.green { background: rgba(76,217,138,0.15); color: #4cd98a; }
        .stat-icon.yellow { background: rgba(251,191,36,0.15); color: #fbbf24; }
        .stat-value {
            font-family: 'Sora', sans-serif;
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--text);
            line-height: 1;
        }
        .stat-label {
            font-size: 0.7rem;
            color: var(--text-muted);
            font-weight: 500;
            letter-spacing: 0.04em;
        }

        /* Cards */
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
            margin-bottom: 1.5rem;
        }
        .card-header {
            padding: 0.9rem 1.2rem;
            border-bottom: 1px solid var(--border);
            background: var(--bg2);
        }
        .card-header h2 {
            font-family: 'Sora', sans-serif;
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text);
        }
        .card-body { padding: 1.2rem; }

        /* Form */
        .form-grid {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .form-group.full { width: 100%; }
        .form-label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            margin-bottom: 0.4rem;
            color: var(--text-muted);
        }
        .required { color: var(--red); }
        .form-control {
            width: 100%;
            padding: 0.6rem 0.85rem;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: 0.85rem;
            font-family: inherit;
            background: var(--bg2);
            color: var(--text);
            transition: border-color 0.15s;
        }
        .form-control:focus { outline: none; border-color: var(--accent); }
        textarea.form-control { min-height: 100px; resize: vertical; }

        .target-selector {
            display: flex;
            gap: 1.5rem;
            flex-wrap: wrap;
        }
        .radio-label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            cursor: pointer;
            color: var(--text-muted);
        }
        .radio-label input { cursor: pointer; }

        .user-search-box { display: none; }
        .user-search-box.open { display: block; }
        .search-input-wrapper { position: relative; }
        .search-icon {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0.85rem;
            opacity: 0.6;
            color: var(--text-dim);
        }
        .search-input-wrapper input { padding-left: 32px; }
        .user-results {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            margin-top: 0.5rem;
            max-height: 200px;
            overflow-y: auto;
            z-index: 10;
        }
        .user-result-item {
            padding: 0.6rem 0.85rem;
            cursor: pointer;
            border-bottom: 1px solid var(--border);
            transition: background 0.12s;
        }
        .user-result-item:hover { background: var(--surface-hv); }
        .user-result-item .name { font-weight: 600; font-size: 0.85rem; color: var(--text); }
        .user-result-item .meta { font-size: 0.7rem; color: var(--text-dim); margin-top: 2px; }
        .selected-user {
            background: var(--surface);
            padding: 0.5rem 0.75rem;
            border-radius: var(--radius-sm);
            margin-top: 0.5rem;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            border: 1px solid var(--border);
            color: var(--text);
        }
        .selected-user .remove {
            cursor: pointer;
            color: var(--red);
            font-weight: 700;
            margin-left: 0.5rem;
        }

        /* Buttons */
        .btn {
            padding: 0.55rem 1.2rem;
            border-radius: var(--radius-sm);
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.12s;
            font-family: inherit;
        }
        .btn-primary { background: var(--accent); color: #fff; }
        .btn-primary:hover { background: var(--primary-dk); transform: translateY(-1px); }
        .btn-secondary { background: var(--surface); border: 1px solid var(--border); color: var(--text-muted); }
        .btn-secondary:hover { background: var(--surface-hv); border-color: var(--accent); color: var(--accent); }
        .btn-danger { background: rgba(248,113,113,0.15); color: var(--red); }
        .btn-danger:hover { background: rgba(248,113,113,0.25); }
        .btn-sm { padding: 0.3rem 0.8rem; font-size: 0.7rem; }

        /* Email Checkbox */
        .email-checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            padding: 0.6rem 0.9rem;
            background: rgba(59,107,255,0.08);
            border: 1px solid rgba(59,107,255,0.2);
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: all 0.2s;
        }
        .email-checkbox-group:hover {
            background: rgba(59,107,255,0.12);
            border-color: var(--accent);
        }
        .email-checkbox-group input {
            width: 16px;
            height: 16px;
            accent-color: var(--accent);
            cursor: pointer;
            flex-shrink: 0;
        }
        .email-checkbox-group .cb-label {
            font-size: 0.8rem;
            font-weight: 600;
            color: var(--text);
        }
        .email-checkbox-group .cb-sub {
            font-size: 0.7rem;
            color: var(--text-dim);
            margin-top: 2px;
        }
        .email-note {
            font-size: 0.7rem;
            color: var(--yellow);
            margin-top: 0.3rem;
        }

        /* Announcement List */
        .announcement-list {
            display: flex;
            flex-direction: column;
            gap: 1rem;
        }
        .announcement-item {
            background: var(--card-bg);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            overflow: hidden;
            transition: box-shadow 0.15s;
        }
        .announcement-item:hover { box-shadow: var(--shadow-md); }
        .announcement-header {
            padding: 1rem 1.2rem;
            background: var(--bg2);
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            flex-wrap: wrap;
            gap: 0.75rem;
        }
        .announcement-title {
            font-size: 1rem;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 0.3rem;
        }
        .announcement-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            font-size: 0.7rem;
            color: var(--text-dim);
        }
        .announcement-body {
            padding: 1.2rem;
            font-size: 0.85rem;
            color: var(--text-muted);
            line-height: 1.6;
        }
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 0.65rem;
            font-weight: 700;
        }
        .badge-all { background: rgba(96,165,250,0.15); color: #60a5fa; }
        .badge-user { background: rgba(167,139,250,0.15); color: #a78bfa; }

        .empty-state {
            text-align: center;
            padding: 3rem;
            background: var(--card-bg);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
        }
        .empty-state h3 { font-size: 1rem; margin-bottom: 0.25rem; color: var(--text-muted); }
        .empty-state p { font-size: 0.8rem; color: var(--text-dim); }

        /* Theme Toggle */
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: var(--surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text);
            font-size: 1.1rem;
            z-index: 99;
            transition: transform 0.2s;
        }
        .theme-toggle:hover { transform: scale(1.1); background: var(--surface-hv); }

        @media (max-width: 900px) {
            .sidebar { display: none; }
            .main { margin-left: 0; padding: 1rem; }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 700px) {
            .stats-row { grid-template-columns: 1fr; }
            .announcement-header { flex-direction: column; }
        }

        .sidebar-overlay {
          display: none;
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.6);
          z-index: 199;
          backdrop-filter: blur(2px);
        }
        .sidebar-overlay.active { display: block; }

        .mobile-topbar {
          display: none;
          position: fixed;
          top: 0; left: 0; right: 0;
          height: 56px;
          background: var(--sidebar-bg);
          border-bottom: 1px solid var(--sidebar-border);
          align-items: center;
          justify-content: space-between;
          padding: 0 1rem;
          z-index: 198;
        }

        .mobile-brand {
          display: flex;
          align-items: center;
          gap: 10px;
          color: white;
          font-family: 'Sora', sans-serif;
          font-weight: 700;
          font-size: 0.9rem;
        }

        .mobile-brand img { width: 32px; height: 32px; object-fit: contain; border-radius: 6px; }

        .hamburger {
          width: 40px; height: 40px;
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 5px; cursor: pointer;
          border: none;
          background: rgba(255,255,255,0.1);
          border-radius: 8px; padding: 8px;
          transition: background 0.2s;
        }
        .hamburger:hover { background: rgba(255,255,255,0.2); }
        .hamburger span { display: block; width: 20px; height: 2px; background: white; border-radius: 2px; transition: all 0.3s; }
        .hamburger.active span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        .hamburger.active span:nth-child(2) { opacity: 0; transform: scaleX(0); }
        .hamburger.active span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

        .table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }

        @media (max-width: 768px) {
          .mobile-topbar { display: flex; }
          .sidebar { z-index: 200; }
          .main { padding-top: 4.5rem !important; }
          .notif-panel { width: 300px !important; right: 0 !important; left: auto; }
          .stats-grid { grid-template-columns: 1fr 1fr !important; }
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
<div class="mobile-topbar">
  <div class="mobile-brand">
    <img src="../wlogo.png" alt="ADFC" onerror="this.style.display='none'">
    DocuGo
  </div>
  <button class="hamburger" id="hamburgerBtn">
    <span></span><span></span><span></span>
  </button>
</div>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-logo">
            <img id="sidebarLogo" src="../wlogo.png" alt="ADFC Logo">
            <div class="brand-text">
                <div class="brand-name">Asian Development<br>Foundation College</div>
                <div class="brand-sub">DocuGo Admin Panel</div>
            </div>
        </div>
    </div>

    <nav class="sidebar-menu">
        <div class="menu-section">MAIN</div>
        <a href="dashboard.php" class="menu-item">
            <span class="menu-icon">🏠</span> Dashboard
        </a>
        <a href="requests.php" class="menu-item">
            <span class="menu-icon">📄</span> Document Requests
            <?php if ($pendingReqs > 0): ?>
                <span class="menu-badge yellow"><?= $pendingReqs ?></span>
            <?php endif; ?>
        </a>
        <a href="accounts.php" class="menu-item">
            <span class="menu-icon">👥</span> User Accounts
            <?php if ($pendingAccs > 0): ?>
                <span class="menu-badge"><?= $pendingAccs ?></span>
            <?php endif; ?>
        </a>

        <div class="menu-section">RECORDS</div>
        <a href="alumni.php" class="menu-item">
            <span class="menu-icon">🎓</span> Alumni
        </a>
        <a href="tracer.php" class="menu-item">
            <span class="menu-icon">📊</span> Graduate Tracer
        </a>
        <a href="reports.php" class="menu-item">
            <span class="menu-icon">📈</span> Reports
        </a>

        <div class="menu-section">COMMUNICATION</div>
        <a href="announcements.php" class="menu-item active">
            <span class="menu-icon">📢</span> Announcements
        </a>

        <div class="menu-section">SETTINGS</div>
        <a href="document_types.php" class="menu-item">
            <span class="menu-icon">⚙️</span> Document Types
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="../logout.php"><span class="menu-icon">🚪</span> Logout</a>
    </div>
</aside>

<!-- Main Content -->
<main class="main">
    <!-- Topbar -->
    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="fas fa-bullhorn"></i> Announcements</h1>
            <p>Create and manage system announcements for users.</p>
        </div>
        <div class="topbar-right">
            <div class="admin-info"><i class="fas fa-user-circle"></i> <strong><?= escape($_SESSION['user_name']) ?></strong></div>
            <div class="topbar-date"><i class="fas fa-calendar-alt"></i> <?= date('l, F j, Y') ?></div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if ($message): ?>
    <div class="alert alert-<?= $messageType ?>">
        <i class="fas <?= $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle' ?>"></i> <?= escape($message) ?>
    </div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="fas fa-bullhorn"></i></div>
            <div><div class="stat-value"><?= $totalAnnouncements ?></div><div class="stat-label">Total Announcements</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green"><i class="fas fa-user"></i></div>
            <div><div class="stat-value"><?= $targetedAnnouncements ?></div><div class="stat-label">Targeted to User</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon yellow"><i class="fas fa-globe"></i></div>
            <div><div class="stat-value"><?= $systemWideAnnouncements ?></div><div class="stat-label">System-wide</div></div>
        </div>
    </div>

    <!-- Compose Announcement Card -->
    <div class="card">
        <div class="card-header">
            <h2><i class="fas fa-edit"></i> Compose New Announcement</h2>
        </div>
        <div class="card-body">
            <form method="POST" id="announcementForm">
                <input type="hidden" name="action" value="create" id="formAction">
                <input type="hidden" name="announcement_id" id="announcementId">

                <div class="form-grid">
                    <div class="form-group full">
                        <label class="form-label">Title <span class="required">*</span></label>
                        <input type="text" name="title" class="form-control" placeholder="Enter announcement title…" required>
                    </div>

                    <div class="form-group full">
                        <label class="form-label">Message <span class="required">*</span></label>
                        <textarea name="message" class="form-control" placeholder="Enter announcement message…" required></textarea>
                    </div>

                    <div class="form-group full">
                        <label class="form-label">Target Audience</label>
                        <div class="target-selector">
                            <label class="radio-label">
                                <input type="radio" name="target_type" value="all" checked onchange="toggleUserSearch()">
                                <i class="fas fa-globe"></i> All Users (System-wide)
                            </label>
                            <label class="radio-label">
                                <input type="radio" name="target_type" value="user" onchange="toggleUserSearch()">
                                <i class="fas fa-user"></i> Specific User
                            </label>
                        </div>
                    </div>

                    <div class="form-group full user-search-box" id="userSearchBox">
                        <label class="form-label">Search User</label>
                        <div class="search-input-wrapper">
                            <span class="search-icon"><i class="fas fa-search"></i></span>
                            <input type="text" id="userSearchInput" class="form-control" placeholder="Search by name or email…">
                        </div>
                        <div class="user-results" id="userResults" style="display:none;"></div>
                        <div id="selectedUserContainer"></div>
                        <input type="hidden" name="target_user_id" id="targetUserId">
                    </div>

                    <!-- Send to Alumni Email Checkbox -->
                    <div class="form-group full">
                        <label class="form-label">Email Notification</label>
                        <label class="email-checkbox-group">
                            <input type="checkbox" name="send_email_alumni" value="1">
                            <div>
                                <div class="cb-label"><i class="fas fa-envelope"></i> Send to active alumni via email</div>
                                <div class="cb-sub">All active alumni will receive this announcement as an email</div>
                            </div>
                        </label>
                        <div class="email-note">
                            <i class="fas fa-info-circle"></i> Emails will be sent to first 50 active alumni (<?= number_format($activeAlumniCount) ?> total active alumni). Limit applies to prevent timeout.
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:0.75rem; margin-top: 1rem;">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Announcement</button>
                    <button type="button" class="btn btn-secondary" id="cancelEditBtn" style="display:none;" onclick="cancelEdit()"><i class="fas fa-times"></i> Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Announcements List -->
    <div class="announcement-list">
        <?php if (empty($announcements)): ?>
            <div class="empty-state">
                <div style="font-size:2.5rem;margin-bottom:0.75rem;">📭</div>
                <h3>No announcements yet</h3>
                <p>Create your first announcement above.</p>
            </div>
        <?php else: ?>
            <?php foreach ($announcements as $ann): ?>
            <div class="announcement-item">
                <div class="announcement-header">
                    <div>
                        <div class="announcement-title"><?= escape($ann['title']) ?></div>
                        <div class="announcement-meta">
                            <span><i class="fas fa-user"></i> <?= escape($ann['first_name'] . ' ' . $ann['last_name']) ?></span>
                            <span><i class="fas fa-clock"></i> <?= timeAgo($ann['created_at']) ?></span>
                            <span class="badge <?= $ann['target_type'] === 'all' ? 'badge-all' : 'badge-user' ?>">
                                <?= $ann['target_type'] === 'all' ? '<i class="fas fa-globe"></i> All Users' : '<i class="fas fa-user"></i> Specific User' ?>
                            </span>
                            <?php if ($ann['target_type'] === 'user' && $ann['target_user_id']): ?>
                                <span><i class="fas fa-id-card"></i> User ID: <?= $ann['target_user_id'] ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div style="display:flex;gap:0.5rem;">
                        <button class="btn btn-secondary btn-sm" onclick="editAnnouncement(<?= $ann['id'] ?>)"><i class="fas fa-edit"></i> Edit</button>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this announcement?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="announcement_id" value="<?= $ann['id'] ?>">
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i> Delete</button>
                        </form>
                    </div>
                </div>
                <div class="announcement-body">
                    <?= nl2br(escape($ann['message'])) ?>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</main>

<!-- Theme Toggle -->
<div class="theme-toggle" id="themeToggleBtn">
    <i class="fas fa-moon"></i>
</div>

<script>
// Theme Toggle
const applyLogoForTheme = (isLight) => {
    const logoImg = document.getElementById('sidebarLogo');
    if (logoImg) logoImg.src = isLight ? '../wlogo.png' : '../wlogo.png';
};
const savedTheme = localStorage.getItem('docugoTheme');
const isLightOnLoad = savedTheme === 'light';
if (isLightOnLoad) {
    document.body.classList.add('light');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fas fa-sun"></i>';
} else {
    document.body.classList.remove('light');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fas fa-moon"></i>';
}
applyLogoForTheme(isLightOnLoad);
document.getElementById('themeToggleBtn').addEventListener('click', () => {
    const isLight = document.body.classList.toggle('light');
    localStorage.setItem('docugoTheme', isLight ? 'light' : 'dark');
    document.getElementById('themeToggleBtn').innerHTML = isLight ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    applyLogoForTheme(isLight);
});

// User search functions
function toggleUserSearch() {
    const targetUser = document.querySelector('input[name="target_type"][value="user"]');
    const userSearchBox = document.getElementById('userSearchBox');
    if (targetUser && targetUser.checked) {
        userSearchBox.classList.add('open');
    } else {
        userSearchBox.classList.remove('open');
        clearSelectedUser();
    }
}

const searchInput = document.getElementById('userSearchInput');
const userResults = document.getElementById('userResults');
let selectedUserId = null;

if (searchInput) {
    searchInput.addEventListener('input', function() {
        const query = this.value.trim();
        if (query.length < 2) {
            userResults.style.display = 'none';
            return;
        }

        fetch('?ajax_search_users=1&q=' + encodeURIComponent(query))
            .then(r => r.json())
            .then(users => {
                if (users.length === 0) {
                    userResults.innerHTML = '<div class="user-result-item" style="color:var(--text-dim);">No users found</div>';
                    userResults.style.display = 'block';
                    return;
                }
                userResults.innerHTML = users.map(u => `
                    <div class="user-result-item" onclick="selectUser(${u.id}, '${escapeJS(u.first_name + ' ' + u.last_name)}', '${escapeJS(u.email)}', '${escapeJS(u.role)}')">
                        <div class="name">${escapeHTML(u.first_name)} ${escapeHTML(u.last_name)}</div>
                        <div class="meta">${escapeHTML(u.email)} · ${escapeHTML(u.role)}</div>
                    </div>
                `).join('');
                userResults.style.display = 'block';
            })
            .catch(err => console.error('Search error:', err));
    });
}

function selectUser(id, name, email, role) {
    selectedUserId = id;
    document.getElementById('targetUserId').value = id;
    document.getElementById('userResults').style.display = 'none';
    if (searchInput) searchInput.value = name;

    const container = document.getElementById('selectedUserContainer');
    if (container) {
        container.innerHTML = `
            <div class="selected-user">
                <span><i class="fas fa-user"></i> ${escapeHTML(name)}</span>
                <span class="remove" onclick="clearSelectedUser()"><i class="fas fa-times-circle"></i></span>
            </div>
        `;
    }
}

function clearSelectedUser() {
    selectedUserId = null;
    document.getElementById('targetUserId').value = '';
    const container = document.getElementById('selectedUserContainer');
    if (container) container.innerHTML = '';
    if (searchInput) searchInput.value = '';
    if (userResults) userResults.style.display = 'none';
}

function escapeHTML(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function escapeJS(str) {
    return str.replace(/\\/g, '\\\\').replace(/'/g, "\\'");
}

// Edit announcement
function editAnnouncement(id) {
    fetch('?ajax_get_announcement=1&id=' + id)
        .then(r => r.json())
        .then(data => {
            document.getElementById('formAction').value = 'update';
            document.getElementById('announcementId').value = data.id;
            document.querySelector('input[name="title"]').value = data.title;
            document.querySelector('textarea[name="message"]').value = data.message;

            const targetAll = document.querySelector('input[name="target_type"][value="all"]');
            const targetUser = document.querySelector('input[name="target_type"][value="user"]');

            if (data.target_type === 'all') {
                if (targetAll) targetAll.checked = true;
                toggleUserSearch();
            } else {
                if (targetUser) targetUser.checked = true;
                toggleUserSearch();
                if (data.target_user_id) {
                    fetch('?ajax_get_user=1&id=' + data.target_user_id)
                        .then(r => r.json())
                        .then(user => {
                            selectUser(user.id, user.first_name + ' ' + user.last_name, user.email, user.role);
                        });
                }
            }

            document.getElementById('cancelEditBtn').style.display = 'inline-flex';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
}

function cancelEdit() {
    document.getElementById('announcementForm').reset();
    document.getElementById('formAction').value = 'create';
    document.getElementById('announcementId').value = '';
    document.getElementById('cancelEditBtn').style.display = 'none';
    clearSelectedUser();
    const targetAll = document.querySelector('input[name="target_type"][value="all"]');
    if (targetAll) targetAll.checked = true;
    toggleUserSearch();
}

// Mobile Sidebar
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const hamburgerBtn = document.getElementById('hamburgerBtn');
function openSidebar() {
  sidebar.classList.add('open');
  overlay.classList.add('active');
  hamburgerBtn.classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  sidebar.classList.remove('open');
  overlay.classList.remove('active');
  hamburgerBtn.classList.remove('active');
  document.body.style.overflow = '';
}
hamburgerBtn.addEventListener('click', () => {
  sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
});
overlay.addEventListener('click', closeSidebar);
document.querySelectorAll('.menu-item').forEach(link => {
  link.addEventListener('click', () => { if (window.innerWidth <= 768) closeSidebar(); });
});
</script>

</body>
</html>