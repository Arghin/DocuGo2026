<?php
// ============================================================
// admin/document_types.php
// Manage document types. Includes requires_signature toggle.
// ============================================================
require_once '../includes/config.php';
requireAdmin();

$conn = getConnection();

// Get counts for sidebar badges
$pendingReqs = $conn->query("SELECT COUNT(*) as c FROM document_requests WHERE status = 'pending'")->fetch_assoc()['c'];
$pendingAccs = $conn->query("SELECT COUNT(*) as c FROM users WHERE status = 'pending'")->fetch_assoc()['c'];

$error = $success = '';

// ── Handle POST ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $docId       = intval($_POST['doc_id'] ?? 0);
        $name        = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $fee         = floatval($_POST['fee'] ?? 0);
        $days        = intval($_POST['processing_days'] ?? 3);
        $reqSig      = isset($_POST['requires_signature']) ? 1 : 0;
        $isActive    = isset($_POST['is_active']) ? 1 : 0;

        if (empty($name)) {
            $error = 'Document name is required.';
        } elseif ($fee < 0) {
            $error = 'Fee cannot be negative.';
        } elseif ($days < 1) {
            $error = 'Processing days must be at least 1.';
        } else {
            if ($action === 'add') {
                $chk = $conn->prepare("SELECT id FROM document_types WHERE name = ?");
                $chk->bind_param("s", $name);
                $chk->execute();
                $chk->store_result();
                if ($chk->num_rows > 0) {
                    $error = "A document type with that name already exists.";
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO document_types (name, description, fee, processing_days, requires_signature, is_active)
                        VALUES (?, ?, ?, ?, ?, 1)
                    ");
                    $stmt->bind_param("ssdii", $name, $description, $fee, $days, $reqSig);
                    if ($stmt->execute()) {
                        $success = "Document type \"{$name}\" added successfully.";
                    } else {
                        $error = 'Failed to add document type.';
                    }
                    $stmt->close();
                }
                $chk->close();
            } else {
                $chk = $conn->prepare("SELECT id FROM document_types WHERE name = ? AND id != ?");
                $chk->bind_param("si", $name, $docId);
                $chk->execute();
                $chk->store_result();
                if ($chk->num_rows > 0) {
                    $error = "Another document type with that name already exists.";
                } else {
                    $stmt = $conn->prepare("
                        UPDATE document_types
                        SET name = ?, description = ?, fee = ?, processing_days = ?,
                            requires_signature = ?, is_active = ?
                        WHERE id = ?
                    ");
                    $stmt->bind_param("ssdiiii", $name, $description, $fee, $days, $reqSig, $isActive, $docId);
                    if ($stmt->execute()) {
                        $success = "Document type updated successfully.";
                    } else {
                        $error = 'Update failed.';
                    }
                    $stmt->close();
                }
                $chk->close();
            }
        }
    }

    if ($action === 'delete') {
        $docId = intval($_POST['doc_id'] ?? 0);
        $check = $conn->prepare("SELECT COUNT(*) AS c FROM document_requests WHERE document_type_id = ?");
        $check->bind_param("i", $docId);
        $check->execute();
        $cnt = $check->get_result()->fetch_assoc()['c'];
        $check->close();

        if ($cnt > 0) {
            $error = "Cannot delete: {$cnt} request(s) reference this document type. Deactivate it instead.";
        } else {
            $del = $conn->prepare("DELETE FROM document_types WHERE id = ?");
            $del->bind_param("i", $docId);
            $del->execute();
            $del->close();
            $success = 'Document type deleted.';
        }
    }

    if ($action === 'toggle_active') {
        $docId    = intval($_POST['doc_id'] ?? 0);
        $newState = intval($_POST['new_state'] ?? 0);
        $stmt = $conn->prepare("UPDATE document_types SET is_active = ? WHERE id = ?");
        $stmt->bind_param("ii", $newState, $docId);
        $stmt->execute();
        $stmt->close();
        $success = $newState ? 'Document type activated.' : 'Document type deactivated.';
    }
}

// ── Filter by status ──────────────────────────────────────
$filterActive = $_GET['filter'] ?? 'all';
$allowedFilters = ['all', 'active', 'inactive'];
if (!in_array($filterActive, $allowedFilters)) $filterActive = 'all';

// ── Fetch all document types ──────────────────────────────
$sql = "
    SELECT dt.*,
           (SELECT COUNT(*) FROM document_requests dr WHERE dr.document_type_id = dt.id) AS total_requests
    FROM document_types dt
";
if ($filterActive === 'active') $sql .= " WHERE dt.is_active = 1";
if ($filterActive === 'inactive') $sql .= " WHERE dt.is_active = 0";
$sql .= " ORDER BY dt.is_active DESC, dt.name ASC";

$types = $conn->query($sql);

// Count stats
$countResult = $conn->query("SELECT COUNT(*) AS total, SUM(is_active) AS active_count FROM document_types");
$counts = $countResult->fetch_assoc();
$totalCount = intval($counts['total']);
$activeCount = intval($counts['active_count']);
$inactiveCount = $totalCount - $activeCount;

// Fetch single type for edit (GET ?edit=id)
$editDoc = null;
if (isset($_GET['edit'])) {
    $editId  = intval($_GET['edit']);
    $editStmt = $conn->prepare("SELECT * FROM document_types WHERE id = ?");
    $editStmt->bind_param("i", $editId);
    $editStmt->execute();
    $editDoc = $editStmt->get_result()->fetch_assoc();
    $editStmt->close();
}

$conn->close();

function escape($v) { return htmlspecialchars($v ?? ''); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Document Types — ADFC DocuGo</title>
    <link href="https://fonts.googleapis.com/css2?family=Sora:wght@300;400;600;700;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        /* ========== THEME VARIABLES ========== */
        :root {
            --primary:    #1a3ec7;
            --primary-dk: #1230a0;
            --accent:     #3b6bff;
            --accent2:    #6b9fff;
            --bg:         #080e28;
            --bg2:        #0b1535;
            --bg3:        #0e1c42;
            --surface:    rgba(255,255,255,0.05);
            --surface-hv: rgba(255,255,255,0.08);
            --border:     rgba(255,255,255,0.08);
            --border-hv:  rgba(59,107,255,0.25);
            --text:       #dce6f8;
            --text-muted: #7a96c4;
            --text-dim:   #4a6190;
            --green:      #4cd98a;
            --yellow:     #fbbf24;
            --purple:     #a78bfa;
            --red:        #f87171;
            --blue:       #60a5fa;
            --radius-sm:  8px;
            --radius-md:  12px;
            --radius-lg:  16px;
            --radius-xl:  24px;
            --sidebar-width: 260px;
            --ease-out:   cubic-bezier(0.16, 1, 0.3, 1);
            --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
            
            --sidebar-bg: #0f2a6b;
            --sidebar-border: rgba(255,255,255,0.1);
            --sidebar-text: #b8c9f0;
            --sidebar-text-hover: #ffffff;
            --sidebar-active-bg: rgba(59,107,255,0.25);
            --sidebar-active-color: #ffffff;
            --sidebar-section: #8eabff;
            --card-bg: rgba(255,255,255,0.05);
        }

        body.light {
            --bg:         #eef2ff;
            --bg2:        #e2e9ff;
            --bg3:        #d8e2ff;
            --surface:    rgba(255,255,255,0.6);
            --surface-hv: rgba(255,255,255,0.85);
            --border:     rgba(26,62,199,0.1);
            --border-hv:  rgba(26,62,199,0.25);
            --text:       #0c1836;
            --text-muted: #3d5a92;
            --text-dim:   #7a96c4;
            --card-bg: #ffffff;
            
            --sidebar-bg: #2d4ed6;
            --sidebar-border: rgba(255,255,255,0.15);
            --sidebar-text: #e0e8ff;
            --sidebar-text-hover: #ffffff;
            --sidebar-active-bg: rgba(255,255,255,0.2);
            --sidebar-active-color: #ffffff;
            --sidebar-section: #c7d5ff;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            transition: background 0.3s, color 0.3s;
            overflow-x: hidden;
            display: flex;
        }

        /* ========== SIDEBAR ========== */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: var(--sidebar-bg);
            border-right: 1px solid var(--sidebar-border);
            display: flex;
            flex-direction: column;
            z-index: 100;
            transition: transform 0.3s var(--ease-out), background 0.3s;
        }

        .sidebar-brand {
            padding: 1.5rem 1.2rem;
            border-bottom: 1px solid var(--sidebar-border);
            margin-bottom: 1rem;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .brand-logo img {
            width: 48px;
            height: 48px;
            object-fit: contain;
            border-radius: 12px;
            transition: transform 0.3s var(--ease-spring);
        }

        .brand-logo img:hover {
            transform: rotate(-5deg) scale(1.05);
        }

        .brand-text {
            flex: 1;
        }

        .brand-name {
            font-family: 'Sora', sans-serif;
            font-weight: 800;
            font-size: 0.9rem;
            color: white;
            line-height: 1.2;
        }

        .brand-sub {
            font-size: 0.55rem;
            color: rgba(255,255,255,0.7);
            margin-top: 3px;
            letter-spacing: 0.3px;
        }

        .sidebar-menu {
            flex: 1;
            padding: 0 0.8rem;
        }

        .menu-section {
            font-size: 0.65rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--sidebar-section);
            padding: 0.8rem 0.8rem 0.5rem;
        }

        .menu-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0.7rem 0.8rem;
            border-radius: var(--radius-sm);
            color: var(--sidebar-text);
            text-decoration: none;
            font-size: 0.85rem;
            font-weight: 500;
            transition: all 0.2s;
            margin-bottom: 2px;
        }

        .menu-item:hover {
            background: var(--sidebar-active-bg);
            color: var(--sidebar-text-hover);
        }

        .menu-item.active {
            background: var(--sidebar-active-bg);
            color: var(--sidebar-active-color);
            border-left: 2px solid white;
        }

        .menu-icon {
            font-size: 1.1rem;
            width: 24px;
        }

        .menu-badge {
            margin-left: auto;
            background: rgba(255,255,255,0.25);
            color: white;
            font-size: 0.65rem;
            font-weight: 700;
            padding: 2px 8px;
            border-radius: 20px;
        }

        .menu-badge.yellow { background: var(--yellow); color: #1a1a2e; }

        .sidebar-footer {
            padding: 1rem 0.8rem;
            border-top: 1px solid var(--sidebar-border);
            margin-top: auto;
        }

        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 0.7rem 0.8rem;
            color: var(--sidebar-text);
            text-decoration: none;
            border-radius: var(--radius-sm);
            transition: all 0.2s;
        }

        .sidebar-footer a:hover {
            background: var(--sidebar-active-bg);
            color: var(--red);
        }

        /* ========== MAIN CONTENT ========== */
        .main {
            margin-left: var(--sidebar-width);
            padding: 1.5rem 2rem;
            min-height: 100vh;
            flex: 1;
        }

        /* Topbar */
        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .topbar-left h1 {
            font-family: 'Sora', sans-serif;
            font-size: 1.6rem;
            font-weight: 700;
            color: var(--text);
            margin-bottom: 0.2rem;
        }

        .topbar-left p {
            color: var(--text-muted);
            font-size: 0.85rem;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .admin-info, .topbar-date {
            background: var(--surface);
            padding: 0.5rem 1rem;
            border-radius: var(--radius-sm);
            font-size: 0.85rem;
            border: 1px solid var(--border);
        }

        /* Alert */
        .alert {
            padding: 0.85rem 1rem;
            border-radius: 10px;
            margin-bottom: 1.2rem;
            font-size: 0.85rem;
        }
        .alert-success { background: rgba(76,217,138,0.15); color: var(--green); border-left: 4px solid var(--green); }
        .alert-error   { background: rgba(248,113,113,0.15); color: var(--red); border-left: 4px solid var(--red); }

        /* Stats Row */
        .stats-row {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 1rem;
            margin-bottom: 1.5rem;
        }
        .stat-card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            padding: 1rem 1.1rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: transform 0.2s;
        }
        .stat-card:hover { transform: translateY(-2px); border-color: var(--border-hv); }
        .stat-icon {
            width: 48px; height: 48px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.4rem;
        }
        .stat-icon.blue { background: rgba(96,165,250,0.15); color: #60a5fa; }
        .stat-icon.green { background: rgba(76,217,138,0.15); color: #4cd98a; }
        .stat-icon.red { background: rgba(248,113,113,0.15); color: #f87171; }
        .stat-value {
            font-family: 'Sora', sans-serif;
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--text);
            line-height: 1;
        }
        .stat-label {
            font-size: 0.7rem;
            color: var(--text-muted);
            font-weight: 500;
            letter-spacing: 0.04em;
        }

        /* Toolbar & Tabs */
        .toolbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.8rem;
            margin-bottom: 1.2rem;
        }
        .tab-group {
            display: flex;
            gap: 0.25rem;
            background: var(--surface);
            padding: 0.5rem;
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            flex-wrap: wrap;
        }
        .tab {
            padding: 0.45rem 1rem;
            font-size: 0.75rem;
            font-weight: 600;
            color: var(--text-muted);
            text-decoration: none;
            border-radius: var(--radius-sm);
            transition: all 0.15s;
        }
        .tab:hover { background: var(--bg2); color: var(--accent); }
        .tab.active { background: var(--accent); color: #fff; }

        /* Layout Grid */
        .layout {
            display: grid;
            grid-template-columns: 360px 1fr;
            gap: 1.2rem;
        }

        /* Cards */
        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius-lg);
            overflow: hidden;
        }
        .card-header {
            padding: 0.9rem 1.2rem;
            border-bottom: 1px solid var(--border);
            background: var(--bg2);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 0.5rem;
        }
        .card-header h3 {
            font-family: 'Sora', sans-serif;
            font-size: 0.9rem;
            font-weight: 700;
            color: var(--text);
            margin: 0;
        }
        .card-body { padding: 1.2rem; }

        /* Form */
        .form-group { margin-bottom: 1rem; }
        .form-group label {
            display: block;
            font-size: 0.75rem;
            font-weight: 700;
            color: var(--text-muted);
            margin-bottom: 0.3rem;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group textarea {
            width: 100%;
            padding: 0.6rem 0.85rem;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-family: inherit;
            font-size: 0.85rem;
            color: var(--text);
            background: var(--bg2);
            outline: none;
            transition: border-color 0.15s;
        }
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(59,107,255,0.1);
        }
        .form-group textarea { resize: vertical; min-height: 70px; }

        .row-2 {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.75rem;
        }

        /* Checkbox Group */
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 0.6rem;
            padding: 0.6rem 0.85rem;
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: all 0.15s;
        }
        .checkbox-group input {
            width: 16px;
            height: 16px;
            cursor: pointer;
            flex-shrink: 0;
        }
        .checkbox-group .cb-label {
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--text);
        }
        .checkbox-group .cb-sub {
            font-size: 0.7rem;
            color: var(--text-dim);
            margin-top: 1px;
        }
        .sig-checkbox {
            border-color: rgba(167,139,250,0.3);
            background: rgba(167,139,250,0.05);
        }
        .sig-checkbox .cb-label { color: var(--purple); }

        /* Buttons */
        .btn-submit {
            width: 100%;
            padding: 0.7rem;
            background: var(--accent);
            color: #fff;
            border: none;
            border-radius: var(--radius-sm);
            font-family: inherit;
            font-size: 0.85rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            margin-top: 0.5rem;
        }
        .btn-submit:hover { background: var(--primary-dk); transform: translateY(-1px); }
        .btn-reset {
            width: 100%;
            padding: 0.6rem;
            background: var(--surface);
            color: var(--text-muted);
            border: 1px solid var(--border);
            border-radius: var(--radius-sm);
            font-family: inherit;
            font-size: 0.8rem;
            font-weight: 600;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            display: block;
            margin-top: 0.5rem;
        }
        .btn-reset:hover {
            background: var(--surface-hv);
            border-color: var(--accent);
            color: var(--accent);
        }

        /* Table */
        .table-wrap {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }
        table { width: 100%; border-collapse: collapse; font-size: 0.8rem; min-width: 700px; }
        th {
            text-align: left;
            padding: 0.75rem 1rem;
            background: var(--bg2);
            color: var(--text-dim);
            font-weight: 700;
            font-size: 0.68rem;
            text-transform: uppercase;
            letter-spacing: 0.06em;
            border-bottom: 1px solid var(--border);
        }
        td {
            padding: 0.75rem 1rem;
            border-bottom: 1px solid var(--border);
            color: var(--text-muted);
            vertical-align: middle;
        }
        tr:hover td { background: var(--surface-hv); }

        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 9px;
            border-radius: 20px;
            font-size: 0.68rem;
            font-weight: 700;
        }
        .badge-active   { background: rgba(76,217,138,0.15); color: #4cd98a; }
        .badge-inactive { background: rgba(248,113,113,0.15); color: #f87171; }
        .badge-sig      { background: rgba(167,139,250,0.15); color: #a78bfa; }
        .badge-nosig    { background: rgba(255,255,255,0.1); color: var(--text-muted); }

        /* Action Buttons */
        .act-btn {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            font-size: 0.68rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            text-decoration: none;
            transition: all 0.12s;
            margin-right: 0.3rem;
        }
        .act-btn:hover { filter: brightness(0.95); transform: translateY(-1px); }
        .act-edit     { background: rgba(96,165,250,0.15); color: #60a5fa; }
        .act-toggle   { background: rgba(251,191,36,0.15); color: #fbbf24; }
        .act-activate { background: rgba(76,217,138,0.15); color: #4cd98a; }
        .act-delete   { background: rgba(248,113,113,0.15); color: #f87171; }

        .empty-row td { text-align: center; padding: 2rem; color: var(--text-dim); }

        /* Theme Toggle */
        .theme-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: var(--surface);
            backdrop-filter: blur(12px);
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            color: var(--text);
            font-size: 1.1rem;
            z-index: 99;
            transition: transform 0.2s;
        }
        .theme-toggle:hover { transform: scale(1.1); background: var(--surface-hv); }

        @media (max-width: 1024px) {
            .layout { grid-template-columns: 1fr; }
            .stats-row { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main { margin-left: 0; padding: 1rem; }
            .stats-row { grid-template-columns: 1fr; }
            .row-2 { grid-template-columns: 1fr; }
        }

        .sidebar-overlay {
          display: none;
          position: fixed;
          inset: 0;
          background: rgba(0,0,0,0.6);
          z-index: 199;
          backdrop-filter: blur(2px);
        }
        .sidebar-overlay.active { display: block; }

        .mobile-topbar {
          display: none;
          position: fixed;
          top: 0; left: 0; right: 0;
          height: 56px;
          background: var(--sidebar-bg);
          border-bottom: 1px solid var(--sidebar-border);
          align-items: center;
          justify-content: space-between;
          padding: 0 1rem;
          z-index: 198;
        }

        .mobile-brand {
          display: flex;
          align-items: center;
          gap: 10px;
          color: white;
          font-family: 'Sora', sans-serif;
          font-weight: 700;
          font-size: 0.9rem;
        }

        .mobile-brand img { width: 32px; height: 32px; object-fit: contain; border-radius: 6px; }

        .hamburger {
          width: 40px; height: 40px;
          display: flex; flex-direction: column;
          align-items: center; justify-content: center;
          gap: 5px; cursor: pointer;
          border: none;
          background: rgba(255,255,255,0.1);
          border-radius: 8px; padding: 8px;
          transition: background 0.2s;
        }
        .hamburger:hover { background: rgba(255,255,255,0.2); }
        .hamburger span { display: block; width: 20px; height: 2px; background: white; border-radius: 2px; transition: all 0.3s; }
        .hamburger.active span:nth-child(1) { transform: translateY(7px) rotate(45deg); }
        .hamburger.active span:nth-child(2) { opacity: 0; transform: scaleX(0); }
        .hamburger.active span:nth-child(3) { transform: translateY(-7px) rotate(-45deg); }

        @media (max-width: 768px) {
          .mobile-topbar { display: flex; }
          .sidebar { z-index: 200; }
          .main { padding-top: 4.5rem !important; }
          .notif-panel { width: 300px !important; right: 0 !important; left: auto; }
          .stats-grid { grid-template-columns: 1fr 1fr !important; }
        }
    </style>
</head>
<body>

<div class="sidebar-overlay" id="sidebarOverlay"></div>
<div class="mobile-topbar">
  <div class="mobile-brand">
    <img src="../wlogo.png" alt="ADFC" onerror="this.style.display='none'">
    DocuGo
  </div>
  <button class="hamburger" id="hamburgerBtn">
    <span></span><span></span><span></span>
  </button>
</div>

<!-- Sidebar -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <div class="brand-logo">
            <img id="sidebarLogo" src="../wlogo.png" alt="ADFC Logo">
            <div class="brand-text">
                <div class="brand-name">Asian Development<br>Foundation College</div>
                <div class="brand-sub">DocuGo Admin Panel</div>
            </div>
        </div>
    </div>

    <nav class="sidebar-menu">
        <div class="menu-section">MAIN</div>
        <a href="dashboard.php" class="menu-item">
            <span class="menu-icon">🏠</span> Dashboard
        </a>
        <a href="requests.php" class="menu-item">
            <span class="menu-icon">📄</span> Document Requests
            <?php if ($pendingReqs > 0): ?>
                <span class="menu-badge yellow"><?= $pendingReqs ?></span>
            <?php endif; ?>
        </a>
        <a href="accounts.php" class="menu-item">
            <span class="menu-icon">👥</span> User Accounts
            <?php if ($pendingAccs > 0): ?>
                <span class="menu-badge"><?= $pendingAccs ?></span>
            <?php endif; ?>
        </a>

        <div class="menu-section">RECORDS</div>
        <a href="alumni.php" class="menu-item">
            <span class="menu-icon">🎓</span> Alumni
        </a>
        <a href="tracer.php" class="menu-item">
            <span class="menu-icon">📊</span> Graduate Tracer
        </a>
        <a href="reports.php" class="menu-item">
            <span class="menu-icon">📈</span> Reports
        </a>

        <div class="menu-section">COMMUNICATION</div>
        <a href="announcements.php" class="menu-item">
            <span class="menu-icon">📢</span> Announcements
        </a>

        <div class="menu-section">SETTINGS</div>
        <a href="document_types.php" class="menu-item active">
            <span class="menu-icon">⚙️</span> Document Types
        </a>
    </nav>

    <div class="sidebar-footer">
        <a href="../logout.php"><span class="menu-icon">🚪</span> Logout</a>
    </div>
</aside>

<!-- Main Content -->
<main class="main">
    <!-- Topbar -->
    <div class="topbar">
        <div class="topbar-left">
            <h1><i class="fas fa-cog"></i> Document Types</h1>
            <p>Manage document types, fees, processing times, and signature requirements.</p>
        </div>
        <div class="topbar-right">
            <div class="admin-info"><i class="fas fa-user-circle"></i> <strong><?= escape($_SESSION['user_name']) ?></strong></div>
            <div class="topbar-date"><i class="fas fa-calendar-alt"></i> <?= date('l, F j, Y') ?></div>
        </div>
    </div>

    <!-- Flash Messages -->
    <?php if ($error): ?>
        <div class="alert alert-error"><i class="fas fa-exclamation-triangle"></i> <?= escape($error) ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
        <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?= $success ?></div>
    <?php endif; ?>

    <!-- Stats Cards -->
    <div class="stats-row">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="fas fa-file-alt"></i></div>
            <div><div class="stat-value"><?= $totalCount ?></div><div class="stat-label">Total Types</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
            <div><div class="stat-value"><?= $activeCount ?></div><div class="stat-label">Active</div></div>
        </div>
        <div class="stat-card">
            <div class="stat-icon red"><i class="fas fa-ban"></i></div>
            <div><div class="stat-value"><?= $inactiveCount ?></div><div class="stat-label">Inactive</div></div>
        </div>
    </div>

    <!-- Filter Tabs -->
    <div class="toolbar">
        <div class="tab-group">
            <?php
            $filters = ['all' => 'All', 'active' => 'Active', 'inactive' => 'Inactive'];
            foreach ($filters as $k => $v):
                $qs = http_build_query(['filter' => $k]);
            ?>
                <a href="?<?= $qs ?>" class="tab <?= $filterActive === $k ? 'active' : '' ?>"><?= $v ?></a>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Layout: Form + Table -->
    <div class="layout">
        <!-- Add / Edit Form Card -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas <?= $editDoc ? 'fa-pen' : 'fa-plus' ?>"></i> <?= $editDoc ? 'Edit Document Type' : 'Add New Document Type' ?></h3>
            </div>
            <div class="card-body">
                <form method="POST" action="<?= $editDoc ? "document_types.php?edit={$editDoc['id']}" : 'document_types.php' ?>">
                    <input type="hidden" name="action" value="<?= $editDoc ? 'edit' : 'add' ?>">
                    <?php if ($editDoc): ?>
                        <input type="hidden" name="doc_id" value="<?= $editDoc['id'] ?>">
                    <?php endif; ?>

                    <div class="form-group">
                        <label>Document Name <span style="color:var(--red);">*</span></label>
                        <input type="text" name="name" placeholder="e.g. Transcript of Records" value="<?= escape($editDoc['name'] ?? '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" placeholder="Brief description of this document…"><?= escape($editDoc['description'] ?? '') ?></textarea>
                    </div>

                    <div class="row-2">
                        <div class="form-group">
                            <label>Processing Fee (₱) <span style="color:var(--red);">*</span></label>
                            <input type="number" name="fee" step="0.01" min="0" value="<?= escape($editDoc['fee'] ?? '0.00') ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Processing Days <span style="color:var(--red);">*</span></label>
                            <input type="number" name="processing_days" min="1" max="365" value="<?= escape($editDoc['processing_days'] ?? '3') ?>" required>
                        </div>
                    </div>

                    <!-- Requires Signature toggle -->
                    <div class="form-group">
                        <label>Signature Requirement</label>
                        <label class="checkbox-group sig-checkbox">
                            <input type="checkbox" name="requires_signature" value="1" <?= ($editDoc['requires_signature'] ?? 0) ? 'checked' : '' ?>>
                            <div>
                                <div class="cb-label"><i class="fas fa-signature"></i> Requires Signature</div>
                                <div class="cb-sub">Request must go through "For Signature" status before processing</div>
                            </div>
                        </label>
                    </div>

                    <?php if ($editDoc): ?>
                        <div class="form-group">
                            <label>Status</label>
                            <label class="checkbox-group">
                                <input type="checkbox" name="is_active" value="1" <?= $editDoc['is_active'] ? 'checked' : '' ?>>
                                <div>
                                    <div class="cb-label"><i class="fas fa-toggle-on"></i> Active</div>
                                    <div class="cb-sub">Inactive types won't appear in the request form</div>
                                </div>
                            </label>
                        </div>
                    <?php endif; ?>

                    <button type="submit" class="btn-submit">
                        <i class="fas <?= $editDoc ? 'fa-save' : 'fa-plus-circle' ?>"></i> <?= $editDoc ? ' Save Changes' : ' Add Document Type' ?>
                    </button>

                    <?php if ($editDoc): ?>
                        <a href="document_types.php" class="btn-reset">
                            <i class="fas fa-times"></i> Cancel Edit
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <!-- Document Types Table -->
        <div class="card">
            <div class="card-header">
                <h3><i class="fas fa-list"></i> All Document Types</h3>
                <span style="font-size:0.7rem; color:var(--text-dim);"><?= $types->num_rows ?> shown</span>
            </div>
            <div class="table-wrap">
                <table>
                    <thead>
                        <tr><th>Name</th><th>Fee</th><th>Days</th><th>Signature</th><th>Status</th><th>Requests</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php if ($types->num_rows === 0): ?>
                            <tr class="empty-row"><td colspan="7">No document types found. Add one to get started.</td></tr>
                        <?php else: ?>
                            <?php while ($dt = $types->fetch_assoc()): ?>
                                <tr>
                                    <td><div style="font-weight:600;color:var(--text)"><?= escape($dt['name']) ?></div><?php if ($dt['description']): ?><div style="font-size:0.65rem;color:var(--text-dim);margin-top:2px"><?= escape(mb_strimwidth($dt['description'], 0, 50, '…')) ?></div><?php endif; ?></td>
                                    <td><strong>₱<?= number_format($dt['fee'], 2) ?></strong></td>
                                    <td><?= $dt['processing_days'] ?> day<?= $dt['processing_days'] > 1 ? 's' : '' ?></td>
                                    <td><?php if ($dt['requires_signature']): ?><span class="badge badge-sig"><i class="fas fa-signature"></i> Required</span><?php else: ?><span class="badge badge-nosig">Not required</span><?php endif; ?></td>
                                    <td><span class="badge <?= $dt['is_active'] ? 'badge-active' : 'badge-inactive' ?>"><?= $dt['is_active'] ? '<i class="fas fa-check-circle"></i> Active' : '<i class="fas fa-ban"></i> Inactive' ?></span></td>
                                    <td><?= number_format($dt['total_requests']) ?></td>
                                    <td style="white-space:nowrap">
                                        <a href="document_types.php?edit=<?= $dt['id'] ?>" class="act-btn act-edit"><i class="fas fa-edit"></i> Edit</a>
                                        <form method="POST" action="document_types.php" style="display:inline">
                                            <input type="hidden" name="action" value="toggle_active">
                                            <input type="hidden" name="doc_id" value="<?= $dt['id'] ?>">
                                            <input type="hidden" name="new_state" value="<?= $dt['is_active'] ? 0 : 1 ?>">
                                            <button class="act-btn <?= $dt['is_active'] ? 'act-toggle' : 'act-activate' ?>">
                                                <?= $dt['is_active'] ? '<i class="fas fa-pause"></i> Deactivate' : '<i class="fas fa-play"></i> Activate' ?>
                                            </button>
                                        </form>
                                        <?php if ($dt['total_requests'] == 0): ?>
                                            <form method="POST" action="document_types.php" style="display:inline" onsubmit="return confirm('Delete this document type permanently?')">
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="doc_id" value="<?= $dt['id'] ?>">
                                                <button class="act-btn act-delete"><i class="fas fa-trash"></i> Delete</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<!-- Theme Toggle -->
<div class="theme-toggle" id="themeToggleBtn">
    <i class="fas fa-moon"></i>
</div>

<script>
// Theme Toggle
const applyLogoForTheme = (isLight) => {
    const logoImg = document.getElementById('sidebarLogo');
    if (logoImg) logoImg.src = isLight ? '../wlogo.png' : '../wlogo.png';
};
const savedTheme = localStorage.getItem('docugoTheme');
const isLightOnLoad = savedTheme === 'light';
if (isLightOnLoad) {
    document.body.classList.add('light');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fas fa-sun"></i>';
} else {
    document.body.classList.remove('light');
    document.getElementById('themeToggleBtn').innerHTML = '<i class="fas fa-moon"></i>';
}
applyLogoForTheme(isLightOnLoad);
document.getElementById('themeToggleBtn').addEventListener('click', () => {
    const isLight = document.body.classList.toggle('light');
    localStorage.setItem('docugoTheme', isLight ? 'light' : 'dark');
    document.getElementById('themeToggleBtn').innerHTML = isLight ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    applyLogoForTheme(isLight);
});

// Mobile Sidebar
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebarOverlay');
const hamburgerBtn = document.getElementById('hamburgerBtn');
function openSidebar() {
  sidebar.classList.add('open');
  overlay.classList.add('active');
  hamburgerBtn.classList.add('active');
  document.body.style.overflow = 'hidden';
}
function closeSidebar() {
  sidebar.classList.remove('open');
  overlay.classList.remove('active');
  hamburgerBtn.classList.remove('active');
  document.body.style.overflow = '';
}
hamburgerBtn.addEventListener('click', () => {
  sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
});
overlay.addEventListener('click', closeSidebar);
document.querySelectorAll('.menu-item').forEach(link => {
  link.addEventListener('click', () => { if (window.innerWidth <= 768) closeSidebar(); });
});
</script>

</body>
</html>