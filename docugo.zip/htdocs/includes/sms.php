<?php
// includes/sms.php
// SMS notification using Semaphore API (Philippine SMS gateway)
// Free tier available at semaphore.co

function sendSMS($number, $message) {
    // Check if API key is configured
    if (!defined('SMS_API_KEY') || SMS_API_KEY === '') {
        return false;
    }
    
    // Clean and format phone number for Philippines
    // Strip all non-digits
    $number = preg_replace('/[^0-9]/', '', $number);
    
    // Format: if starts with 0, replace with 63
    if (substr($number, 0, 1) === '0') {
        $number = '63' . substr($number, 1);
    }
    // if starts with 9, prepend 63
    elseif (substr($number, 0, 1) === '9') {
        $number = '63' . $number;
    }
    
    // Validate number length (Philippines: 63 + 10 digits = 12 digits)
    if (strlen($number) !== 12) {
        error_log("SMS: Invalid Philippine number format after cleaning: $number");
        return false;
    }
    
    // Truncate message to 160 characters
    $message = substr($message, 0, 160);
    
    // Prepare POST data
    $postData = [
        'apikey'    => SMS_API_KEY,
        'number'    => $number,
        'message'   => $message,
        'sendername' => defined('SMS_SENDER') ? SMS_SENDER : 'DocuGo'
    ];
    
    // Build query string
    $postString = http_build_query($postData);
    
    // Set up stream context
    $options = [
        'http' => [
            'method'  => 'POST',
            'header'  => 'Content-Type: application/x-www-form-urlencoded',
            'content' => $postString,
            'timeout' => 10
        ]
    ];
    
    $context = stream_context_create($options);
    
    try {
        $result = file_get_contents('https://api.semaphore.co/api/v4/messages', false, $context);
        
        if ($result === false) {
            error_log("SMS: Failed to send to $number");
            return false;
        }
        
        // Parse response
        $response = json_decode($result, true);
        
        if (isset($response['status']) && $response['status'] === 'success') {
            error_log("SMS: Successfully sent to $number");
            return true;
        } elseif (isset($response['message'])) {
            error_log("SMS API Error: " . $response['message']);
            return false;
        }
        
        return true;
        
    } catch (Exception $e) {
        error_log("SMS Exception: " . $e->getMessage());
        return false;
    }
}
?>