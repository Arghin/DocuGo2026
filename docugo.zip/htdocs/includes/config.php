<?php
// config.php - Database Configuration

define('DB_HOST', 'sql303.byethost7.com');
define('DB_USER', 'b7_41989262');
define('DB_PASS', 'Docugo2026');
define('DB_NAME', 'b7_41989262_docugo_db');

define('SITE_NAME', 'DocuGo');

// Email settings
define('MAIL_HOST',      'smtp.gmail.com');
define('MAIL_PORT',      587);
define('MAIL_USERNAME',  'buddydudzzz@gmail.com');
define('MAIL_PASSWORD',  'bjyx rxpo jghf lguu');
define('MAIL_FROM',      'buddydudzzz@gmail.com');
define('MAIL_FROM_NAME', 'ADFC DocuGo');

// Base URL — auto switches between localhost and live
if ($_SERVER['HTTP_HOST'] === 'localhost' || str_contains($_SERVER['HTTP_HOST'], '127.0.0.1')) {
    // Local development
    define('SITE_URL', 'http://localhost/docugo');
} else {
    // Live server — files are directly in htdocs/
    define('SITE_URL', 'https://docugo.byethost7.com');
}

// ========== SMS NOTIFICATION SETTINGS ==========
// Get free API key at semaphore.co — leave empty to disable SMS
define('SMS_API_KEY', 'be780c2a13d0c89826696f5614bdfbb0');  // Your Semaphore API key
define('SMS_SENDER', 'ADFC DocuGo');  // Sender name (max 11 characters - will be truncated to "ADFC DocuGo")

// Create connection
function getConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die('Database connection failed: ' . $conn->connect_error);
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Check if admin or registrar
function isAdmin() {
    return isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin', 'registrar']);
}

// Protect student pages
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/login.php');
        exit();
    }
}

// Protect admin pages
function requireAdmin() {
    if (!isLoggedIn()) {
        header('Location: ' . SITE_URL . '/login.php');
        exit();
    }
    if (!isAdmin()) {
        header('Location: ' . SITE_URL . '/dashboard.php');
        exit();
    }
}

// Redirect if already logged in (used on login/register pages)
function redirectIfLoggedIn() {
    if (isLoggedIn()) {
        if (isAdmin()) {
            header('Location: ' . SITE_URL . '/admin/dashboard.php');
        } else {
            header('Location: ' . SITE_URL . '/dashboard.php');
        }
        exit();
    }
}

// Sanitize input
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

// Generate unique request code
function generateRequestCode() {
    return 'REQ-' . strtoupper(substr(md5(uniqid()), 0, 8));
}
?>